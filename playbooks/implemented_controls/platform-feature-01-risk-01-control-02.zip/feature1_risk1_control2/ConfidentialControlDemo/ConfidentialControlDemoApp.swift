import SwiftUI

@main
struct ConfidentialControlDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
